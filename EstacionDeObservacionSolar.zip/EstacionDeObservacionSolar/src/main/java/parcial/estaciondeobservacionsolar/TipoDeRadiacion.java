
package parcial.estaciondeobservacionsolar;


public enum TipoDeRadiacion {
    INFRARROJA,
    ULTRAVIOLETA,
    RAYOS_X
}
