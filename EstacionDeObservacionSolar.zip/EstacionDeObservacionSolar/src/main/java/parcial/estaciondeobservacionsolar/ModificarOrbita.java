
package parcial.estaciondeobservacionsolar;


public interface ModificarOrbita {
    public void modificarOrbita();
}
