
package parcial.estaciondeobservacionsolar;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

public class EstacionDeObservacionSolar {
    
    private final List<Astro> astros = new ArrayList<>();
    
    
    public void agregarAstro(Astro nuevoAstro) throws AstroDuplicadoException{
        for(Astro a: astros){
            if(a.getClass().equals(nuevoAstro.getClass()) && a.getNombreIdentificador().equalsIgnoreCase(nuevoAstro.getNombreIdentificador())){
                throw new AstroDuplicadoException("Ya existe tipo de plato " + 
                        a.getClass().getSimpleName() + "Nombre: " + a.getNombreIdentificador() + ".");
            }       
        }
    astros.add(nuevoAstro);
    }
    
    public void mostrarAstros(){
        for (Astro a : astros){
            System.out.println(a);
        }
    }
    
    
    public void generarCamposMagneticos() throws NoEsCapazException {
        for (Astro a : astros) {
            if (a instanceof GenerarCampoMagnetico) {
                ((GenerarCampoMagnetico) a).generarCampoMagnetico();
            } else {
                throw new NoEsCapazException(a.getNombreIdentificador() + " no puede generar campo magnético.");
            }
        }
    }

    public void modificarOrbitas() throws NoEsCapazException {
        for (Astro a : astros) {
            if (a instanceof ModificarOrbita) {
                ((ModificarOrbita) a).modificarOrbita();
            } else {
                throw new NoEsCapazException(a.getNombreIdentificador() + " no puede modificar órbita.");
            }
        }
    }
    
    
    
    
    
    public void generarCampoMagnetico(String nombre){
        Astro astro = buscarPlatoPorNombre(nombre);
        if (astro != null && astro instanceof GenerarCampoMagnetico){
            ((GenerarCampoMagnetico) astro).generarCampoMagnetico();
            }else{
            System.out.println("El plato  " + nombre + " no es preparable");
        }
    }
    
    
    
    public void filtrarPorTipoRadiacion(TipoDeRadiacion tipo){
        for (Astro a : astros){
            if(a.getTipoDeRadiacion() == tipo){
                System.out.println(a);
            }
        }
    }
       
    public void mostrarAstroPorTipo(String tipoDeAstro){
        for(Astro a : astros){
            if (a.getClass().getSimpleName().equals(tipoDeAstro)){
                System.out.println(a);
            }
    }
    }
    
    
    private Astro buscarPlatoPorNombre(String nombre){
        for(Astro a : astros){
            if(a.getNombreIdentificador().equalsIgnoreCase(nombre)){
                return a;
            }
        }
        throw new NoSuchElementException("No se encontro Astro: " + nombre +  ".");
    }
}
