
package parcial.estaciondeobservacionsolar;


public class Planeta extends Astro implements GenerarCampoMagnetico{
    private boolean tieneAtmosfera;

    public Planeta(String nombreIdentificador, String regiónDelEspacio, TipoDeRadiacion tipoDeRadiacion,boolean tieneAtmosfera) {
        super(nombreIdentificador, regiónDelEspacio, tipoDeRadiacion);
        this.tieneAtmosfera = tieneAtmosfera;
    }
    
    
    
    
    @Override
    public void generarCampoMagnetico() {
        System.out.println(getNombreIdentificador() + "Esta generando campo Magnetico");
    }
    
    @Override
    public String toString(){
       return String.format("Id nombre: %s | Region del espacio: %s | Tipo de radiacion: %s | posee atmosfera: %s", 
                    getNombreIdentificador(), getRegiónDelEspacio(), getTipoDeRadiacion(), tieneAtmosfera ? "Si" : "No");
   }
    
}
