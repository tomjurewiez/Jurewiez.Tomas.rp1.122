
package parcial.estaciondeobservacionsolar;


public class Estrella extends Astro implements GenerarCampoMagnetico, ModificarOrbita {
    private double temperaturaSuperficial;

    public Estrella(String nombreIdentificador, String regiónDelEspacio, TipoDeRadiacion tipoDeRadiacion,double temperaturaSuperficial) {
        super(nombreIdentificador, regiónDelEspacio, tipoDeRadiacion);
        this.temperaturaSuperficial = temperaturaSuperficial;
    }
    
    @Override
   public String toString(){
       return String.format("Id nombre: %s | Region del espacio: %s | Tipo de radiacion: %s | Temperatura superficial: $%.2f K", 
                    getNombreIdentificador(), getRegiónDelEspacio(), getTipoDeRadiacion(), temperaturaSuperficial);
   }

    @Override
    public void generarCampoMagnetico() {
        System.out.println(getNombreIdentificador() + "Esta generando campo Magnetico");
    }

    @Override
    public void modificarOrbita() {
        System.out.println(getNombreIdentificador() + "Esta modificando su orbita");
    }
}
