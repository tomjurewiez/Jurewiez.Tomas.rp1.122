
package parcial.estaciondeobservacionsolar;


public interface GenerarCampoMagnetico {
    public void generarCampoMagnetico();
}
