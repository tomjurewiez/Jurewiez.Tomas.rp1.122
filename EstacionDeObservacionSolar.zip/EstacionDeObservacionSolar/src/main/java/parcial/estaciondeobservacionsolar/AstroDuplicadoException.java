
package parcial.estaciondeobservacionsolar;


public class AstroDuplicadoException extends Exception{
    public AstroDuplicadoException(String mensaje){
        super(mensaje);
    }
}
