
package parcial.estaciondeobservacionsolar;


public class NoEsCapazException extends Exception {
    public NoEsCapazException(String mensaje){
        super(mensaje);
    }
}
