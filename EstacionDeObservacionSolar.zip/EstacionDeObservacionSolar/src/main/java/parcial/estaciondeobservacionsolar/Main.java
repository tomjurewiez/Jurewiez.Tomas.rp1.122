

package parcial.estaciondeobservacionsolar;

import static parcial.estaciondeobservacionsolar.TipoDeRadiacion.ULTRAVIOLETA;


public class Main {

    public static void main(String[] args) {
        EstacionDeObservacionSolar sistema = new EstacionDeObservacionSolar();

        
        try {
            Astro helion = new Estrella("Helion", "Sector A", ULTRAVIOLETA, 3000.0);
            sistema.agregarAstro(helion);
        } catch (AstroDuplicadoException | IllegalArgumentException e) {
            System.out.println("Error al registrar astro: " + e.getMessage());
        }

        
        try {
            Astro duplicado = new Estrella("Helion", "Sector A", ULTRAVIOLETA, 3000.0 );
            sistema.agregarAstro(duplicado);
        } catch (AstroDuplicadoException | IllegalArgumentException e) {
            System.out.println("Error al registrar astro duplicado: " + e.getMessage());
        }

        
        System.out.println("\nAstros registrados:");
        for (Astro astro : sistema.mostrarAstros()) {
            System.out.println(astro);
        }

        
        System.out.println("\nGenerando campos magnéticos:");
        sistema.generarCamposMagneticos();

        
        System.out.println("\nModificando órbitas:");
        sistema.modificarOrbitas();

        
        System.out.println("\nAstros con radiación Gamma:");
        for (Astro astro : sistema.filtrarPorTipoRadiacion(ULTRAVIOLETA)) {
            System.out.println(astro);
        }

        
        System.out.println("\nAstros de tipo Estrella:");
        for (Astro astro : sistema.mostrarAstroPorTipo("Estrella")) {
            System.out.println(astro);
        }
    }

    }
}
