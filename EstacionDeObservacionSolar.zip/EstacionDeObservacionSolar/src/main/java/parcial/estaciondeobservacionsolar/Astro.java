
package parcial.estaciondeobservacionsolar;


public abstract class Astro {
    private String nombreIdentificador;
    private String regiónDelEspacio;
    private TipoDeRadiacion tipoDeRadiacion;

    public Astro(String nombreIdentificador, String regiónDelEspacio, TipoDeRadiacion tipoDeRadiacion) {
        this.nombreIdentificador = nombreIdentificador;
        this.regiónDelEspacio = regiónDelEspacio;
        this.tipoDeRadiacion = tipoDeRadiacion;
    }

    public String getNombreIdentificador() {
        return nombreIdentificador;
    }

    public String getRegiónDelEspacio() {
        return regiónDelEspacio;
    }

    public TipoDeRadiacion getTipoDeRadiacion() {
        return tipoDeRadiacion;
    }

    public void setTipoDeRadiacion(TipoDeRadiacion tipoDeRadiacion) {
        this.tipoDeRadiacion = tipoDeRadiacion;
    }

    
    
    @Override
   public String toString(){
       return String.format("Id nombre: %s | Precio: %s | Preparacion: %s", 
                    getNombreIdentificador(), getRegiónDelEspacio(), getTipoDeRadiacion() );
   }
    
}
