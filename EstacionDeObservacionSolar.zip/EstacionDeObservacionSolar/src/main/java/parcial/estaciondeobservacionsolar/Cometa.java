
package parcial.estaciondeobservacionsolar;


public  class Cometa extends Astro implements ModificarOrbita{
    private Integer periodoOrbital;

    public Cometa(String nombreIdentificador, String regiónDelEspacio, TipoDeRadiacion tipoDeRadiacion, Integer periodoOrbital) {
        super(nombreIdentificador, regiónDelEspacio, tipoDeRadiacion);
        this.periodoOrbital = periodoOrbital;
    }

   
    public void modificarOrbita() {
        System.out.println(getNombreIdentificador() + "Esta modificando su orbita");
    }
    
    
    @Override
    public String toString(){
       return String.format("Id nombre: %s | Region del espacio: %s | Tipo de radiacion: %s | Periodo orbital: %d Años", 
                    getNombreIdentificador(), getRegiónDelEspacio(), getTipoDeRadiacion(), periodoOrbital );
   }
}
